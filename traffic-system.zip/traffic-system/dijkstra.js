export function dijkstra(graph, traffic, start) {
  const dist = {};
  const prev = {};
  const visited = new Set();
  let pq = [];

  for (let node in graph) {
    dist[node] = Infinity;
    prev[node] = null;
  }

  dist[start] = 0;
  pq.push({ node: start, d: 0 });

  while (pq.length) {
    pq.sort((a, b) => a.d - b.d);
    const { node } = pq.shift();

    if (visited.has(node)) continue;
    visited.add(node);

    for (let neighbor in graph[node]) {
      const base = graph[node][neighbor];
      const t = traffic[node][neighbor];

      const newDist = dist[node] + base * t;

      if (newDist < dist[neighbor]) {
        dist[neighbor] = newDist;
        prev[neighbor] = node;
        pq.push({ node: neighbor, d: newDist });
      }
    }
  }

  return { dist, prev };
}

export function getPath(prev, end) {
  const path = [];
  let curr = end;

  while (curr) {
    path.unshift(curr);
    curr = prev[curr];
  }

  return path;
}