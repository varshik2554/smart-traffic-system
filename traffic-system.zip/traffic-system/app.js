import { graph, traffic, updateTraffic } from "./graph.js";
import { dijkstra, getPath } from "./dijkstra.js";
import { chooseGreenSignal } from "./signal.js";
import { createVehicles, vehicles } from "./simulation.js";

const svg = document.getElementById("map");

let emergencyMode = false;

const pos = {
  A: { x: 50, y: 150 },
  B: { x: 150, y: 50 },
  C: { x: 150, y: 250 },
  D: { x: 300, y: 80 },
  E: { x: 300, y: 220 }
};

createVehicles(pos, 5);

// Draw graph
function drawGraph() {
  svg.innerHTML = "";

  for (let u in graph) {
    for (let v in graph[u]) {
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line");

      line.setAttribute("x1", pos[u].x);
      line.setAttribute("y1", pos[u].y);
      line.setAttribute("x2", pos[v].x);
      line.setAttribute("y2", pos[v].y);

      let t = traffic[u][v];

      if (emergencyMode) t = 1; // override traffic

      if (t <= 2) line.setAttribute("stroke", "green");
      else if (t <= 4) line.setAttribute("stroke", "orange");
      else line.setAttribute("stroke", "red");

      svg.appendChild(line);
    }
  }

  // nodes
  for (let n in pos) {
    const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    c.setAttribute("cx", pos[n].x);
    c.setAttribute("cy", pos[n].y);
    c.setAttribute("r", 15);
    c.setAttribute("fill", "#4caf50");
    svg.appendChild(c);
  }
}

// AI Traffic Prediction (simple logic)
function predictTraffic() {
  for (let u in traffic) {
    for (let v in traffic[u]) {
      traffic[u][v] += Math.random() > 0.5 ? 1 : -1;
      if (traffic[u][v] < 1) traffic[u][v] = 1;
      if (traffic[u][v] > 5) traffic[u][v] = 5;
    }
  }
}

// Move vehicles
function moveVehicles() {
  vehicles.forEach(v => {
    if (v.path.length === 0 || v.index >= v.path.length) {
      const { prev } = dijkstra(graph, traffic, v.start);
      v.path = getPath(prev, v.end);
      v.index = 0;
    }

    const node = v.path[v.index];
    const p = pos[node];

    const dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    dot.setAttribute("cx", p.x);
    dot.setAttribute("cy", p.y);
    dot.setAttribute("r", 6);
    dot.setAttribute("fill", "red");

    svg.appendChild(dot);

    v.index++;
  });
}

// Dashboard update
function updateDashboard() {
  document.getElementById("vehCount").innerText = vehicles.length;

  let sum = 0, count = 0;
  for (let u in traffic) {
    for (let v in traffic[u]) {
      sum += traffic[u][v];
      count++;
    }
  }

  document.getElementById("trafficAvg").innerText = (sum / count).toFixed(2);
  document.getElementById("emergencyStatus").innerText = emergencyMode ? "ON" : "OFF";
}

// Signal logic
function updateSignals() {
  const green = chooseGreenSignal(traffic["C"]);
  console.log("Signal at C:", green);
}

// MAIN LOOP (🔥 real system feel)
function loop() {
  updateTraffic();
  predictTraffic();
  drawGraph();
  moveVehicles();
  updateSignals();
  updateDashboard();

  requestAnimationFrame(loop);
}

loop();

// Emergency toggle
document.getElementById("emergencyBtn").onclick = () => {
  emergencyMode = !emergencyMode;
};