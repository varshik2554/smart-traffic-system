export let vehicles = [];

export function createVehicles(pos, count = 3) {
  const keys = Object.keys(pos);

  vehicles = [];

  for (let i = 0; i < count; i++) {
    const start = keys[Math.floor(Math.random() * keys.length)];
    const end = keys[Math.floor(Math.random() * keys.length)];

    vehicles.push({
      id: i,
      path: [],
      index: 0,
      start,
      end
    });
  }
}