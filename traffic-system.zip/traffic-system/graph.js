export const graph = {
  A: { B: 5, C: 2 },
  B: { A: 5, D: 3 },
  C: { A: 2, D: 7, E: 4 },
  D: { B: 3, C: 7, E: 1 },
  E: { C: 4, D: 1 }
};

// Traffic (dynamic weights)
export let traffic = {
  A: { B: 1, C: 1 },
  B: { A: 1, D: 1 },
  C: { A: 1, D: 1, E: 1 },
  D: { B: 1, C: 1, E: 1 },
  E: { C: 1, D: 1 }
};

// Random traffic update
export function updateTraffic() {
  for (let u in traffic) {
    for (let v in traffic[u]) {
      traffic[u][v] = Math.floor(Math.random() * 5) + 1;
    }
  }
}