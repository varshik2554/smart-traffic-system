export function chooseGreenSignal(lanes) {
  let maxLane = null;
  let maxTraffic = -1;

  for (let lane in lanes) {
    if (lanes[lane] > maxTraffic) {
      maxTraffic = lanes[lane];
      maxLane = lane;
    }
  }

  return maxLane;
}